package CalculoDeNota;
import java.util.Scanner;

public class CalculoDeNota {
	//Se el código principal del programa
	public static void main(String[] args) {
		//Presento mi nombre y doy título al examen
		System.out.println("Examen de Bernal Sita, Agustín Nahuel. CÁLCULO DE NOTA FINAL");
		//Importando una utilidad de java (Scanner), puedo ingresar y leer valores 
		Scanner scanner = new Scanner(System.in);
		//Creé las variables necesarias para introducir los datos que se necesitan para el programa
		System.out.println("Introduzca la nota del primer examen");
		double examen1= Double.parseDouble(scanner.nextLine());
		System.out.println("Introduzca la nota del segundo examen");
		double examen2= Double.parseDouble(scanner.nextLine());
		System.out.println("Introduzca la nota del tercer examen");
		double examen3= Double.parseDouble(scanner.nextLine());
		
		System.out.println("Introduzca la nota del primer trabajo");
		double trabajo1= Double.parseDouble(scanner.nextLine());
		System.out.println("Introduzca la nota del segundo trabajo");
		double trabajo2= Double.parseDouble(scanner.nextLine());
		System.out.println("Introduzca la nota del tercer trabajo");
		double trabajo3= Double.parseDouble(scanner.nextLine());
		
		System.out.println("Introduzca la nota del actividad trabajo");
		double actividad1= Double.parseDouble(scanner.nextLine());
		System.out.println("Introduzca la nota del actividad trabajo");
		double actividad2= Double.parseDouble(scanner.nextLine());
		System.out.println("Introduzca la nota del actividad trabajo");
		double actividad3= Double.parseDouble(scanner.nextLine());
		
		System.out.println("Introduzca la nota del profesor");
		double notaProfesor= Double.parseDouble(scanner.nextLine());
		
		System.out.println("Introduzca la nota negativa del alumno");
		double negativos= Double.parseDouble(scanner.nextLine());
		scanner.close();
		//Realicé las variables siguientes para realizar las operaciones y asi dar la nota final del alumno
		double resultado1= (examen1*0.5+examen2*0.5+examen3*0.5)/3;
		double resultado2= (trabajo1*0.2+trabajo2*0.2+trabajo3*0.2)/3;
		double resultado3= (actividad1*0.2+actividad2*0.2+actividad3*0.2)/3;
		double profeNota= notaProfesor/10;
		double notaDefinitiva= resultado1+resultado2+resultado3+profeNota;
		
		if(negativos>10) {
			negativos=10;
		}
		System.out.println("La nota definitiva es: " +(notaDefinitiva-(negativos*0.1)));
	
	
	
	
	}
}
